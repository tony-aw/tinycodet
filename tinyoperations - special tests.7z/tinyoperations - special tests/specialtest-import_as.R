
library(tinyoperations)
library(tinytest)

# get library folder:
lib.loc <- file.path(getwd(), "fake_library")
print(lib.loc)


# error print function:
errorfun <- function(tt) {
  if(isTRUE(tt)) print(tt)
  if(isFALSE(tt)) stop(print(tt))
}

# test import_as - single package:
stri <- loadNamespace("stringi") |> getNamespaceExports()
import_as(stri., "stringi")
expect_equal(names(stri.)|>sort(), sort(stri)) |> errorfun()


# test import_as - error handling:
expect_error(
  import_as(stri., "stringi", lib.loc=lib.loc),
  pattern = "The following packages are not installed"
) |> errorfun()
expect_error(
  import_as(p1., "tinyoperationsfakepkg1", lib.loc=c(lib.loc, .libPaths()), dependencies = "data.table"),
  pattern = "The following given dependencies were not found to be actual dependencies"
) |> errorfun()
expect_error(
  import_as(p1., "tinyoperationsfakepkg1", lib.loc=c(lib.loc, .libPaths()), enhances = "data.table"),
  pattern = "The following given enhances were not found to be actual enhances"
) |> errorfun()
expect_error(
  import_as(p1., "tinyoperationsfakepkg1", lib.loc=c(lib.loc, .libPaths()), extensions = "data.table"),
  pattern = "The following given extensions were not found to be actual reverse dependencies"
) |> errorfun()


# test import_as - foreign exports:
import_as(
  p3., "tinyoperationsfakepkg3",
  foreign_exports=TRUE,
  lib.loc=lib.loc
)
p3 <- c(
  "fun_overwritten", "%opover%",
  "fun11",
  "fun31", "fun32", "%op31%", "%op32%"
)
expect_equal(names(p3.)|>sort(),  sort(p3)) |> errorfun()
expect_true(attributes(p3.)$args$foreign_exports) |> errorfun()

# test import_as - Dependencies:
import_as(
  p3., "tinyoperationsfakepkg3",
  dependencies=c("tinyoperationsfakepkg1", "tinyoperationsfakepkg2"),
  lib.loc=lib.loc
)
p3 <- c(
  "fun_overwritten", "%opover%",
  "fun11", "fun12", "%op11%", "%op12%",
  "fun21", "fun22", "%op21%", "%op22%",
  "fun31", "fun32", "%op31%", "%op32%"
)
expect_equal(names(p3.)|>sort(),  sort(p3)) |> errorfun()
expect_equal(
  attributes(p3.)$conflicts$package,
  c("tinyoperationsfakepkg1", "tinyoperationsfakepkg2", "tinyoperationsfakepkg3 + foreign exports")
) |> errorfun()
expect_equal(
  attributes(p3.)$packages_order,
  c("tinyoperationsfakepkg1", "tinyoperationsfakepkg2", "tinyoperationsfakepkg3")
) |> errorfun()

# test import_as - extensions:
import_as(
  p3., "tinyoperationsfakepkg1",
  extensions = "tinyoperationsfakepkg3",
  lib.loc=lib.loc
)
p3 <- c(
  "fun_overwritten", "%opover%",
  "fun11", "fun12", "%op11%", "%op12%",
  "fun31", "fun32", "%op31%", "%op32%"
)
expect_equal(names(p3.)|>sort(),  sort(p3)) |> errorfun()
expect_equal(
  attributes(p3.)$conflicts$package,
  c("tinyoperationsfakepkg1 + foreign exports", "tinyoperationsfakepkg3")
) |> errorfun()
expect_equal(
  attributes(p3.)$packages_order,
  c("tinyoperationsfakepkg1", "tinyoperationsfakepkg3")
) |> errorfun()


# test import_as - enhances:
import_as(
  p3., "tinyoperationsfakepkg1",
  enhances = "tinyoperationsfakepkg3",
  lib.loc=lib.loc
)
p3 <- c(
  "fun_overwritten", "%opover%",
  "fun11", "fun12", "%op11%", "%op12%",
  "fun31", "fun32", "%op31%", "%op32%"
)
expect_equal(names(p3.)|>sort(),  sort(p3)) |> errorfun()
expect_equal(
  attributes(p3.)$conflicts$package,
  c("tinyoperationsfakepkg1 + foreign exports", "tinyoperationsfakepkg3")
) |> errorfun()
expect_equal(
  attributes(p3.)$packages_order,
  c("tinyoperationsfakepkg1", "tinyoperationsfakepkg3")
) |> errorfun()


